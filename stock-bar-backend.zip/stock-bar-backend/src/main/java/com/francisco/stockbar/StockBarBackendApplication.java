package com.francisco.stockbar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockBarBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockBarBackendApplication.class, args);
	}

}
