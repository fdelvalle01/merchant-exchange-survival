import { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/api/products")
      .then(res => setProducts(res.data))
      .catch(err => console.error("Error cargando productos", err));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📈 Stock Bar</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {products.map(p => (
          <div key={p.id} className="border p-4 rounded shadow">
            <img src={p.imageUrl} alt={p.name} className="w-full h-32 object-cover mb-2" />
            <h2 className="text-lg font-semibold">{p.name}</h2>
            <p>💰 ${p.currentPrice.toLocaleString()}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
